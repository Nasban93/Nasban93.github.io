import { useState, useMemo } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line,
} from "recharts";
import type { SeedData } from "../domain/types";
import { KPI_DEFINITIONS } from "../config/kpiConfig";
import { computeFromStoredScores } from "../domain/scoring";
import { StatCard } from "../components/StatCard";
import { ChartFrame } from "../components/ChartFrame";
import { GradeBadge } from "../components/GradeBadge";
import { gradeColor, tokens } from "../theme/tokens";
import { useT, useLang } from "../i18n/useT";
import { SyntheticDisclaimer } from "../components/SyntheticDisclaimer";
import { EmployeeProfileModal } from "../components/EmployeeProfileModal";
import { COACHING_THRESHOLD } from "../config/gradeBands";
import type { Grade } from "../domain/types";

const PERIODS = ["2025-11","2025-12","2026-01","2026-02","2026-03","2026-04"];
const PERIOD_LABELS: Record<string, string> = {
  "2025-11":"Nov 25","2025-12":"Dec 25","2026-01":"Jan 26",
  "2026-02":"Feb 26","2026-03":"Mar 26","2026-04":"Apr 26",
};

const DEPTS = [
  { id: "front_office", name: "Front Office", nameAr: "مكتب الاستقبال" },
  { id: "housekeeping",  name: "Housekeeping",  nameAr: "التدبير المنزلي" },
];

const TT_STYLE = {
  background: "var(--surface)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  color: "var(--text)",
  boxShadow: "0 4px 16px rgba(0,0,0,0.10)",
};

interface Props { data: SeedData }

type StaffFilter = "all" | "direct" | "casual";

export function HrManager({ data }: Props) {
  const t = useT();
  const { lang } = useLang();
  const isAr = lang === "ar";
  const [period, setPeriod] = useState("2026-04");
  const [staffFilter, setStaffFilter] = useState<StaffFilter>("all");
  const [tableSearch, setTableSearch] = useState("");
  const [sortBy, setSortBy] = useState<"score" | "name" | "dept">("score");
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);

  const employeeResults = useMemo(() => {
    return data.employees
      .filter((e) => {
        if (e.employmentStatus !== "Active") return false;
        if (staffFilter === "direct") return e.staffType !== "casual";
        if (staffFilter === "casual") return e.staffType === "casual";
        return true;
      })
      .map((emp) => {
        const deptKpis = KPI_DEFINITIONS.filter((k) => k.departmentId === emp.departmentId && k.active);
        const empScores = data.kpiScores.filter((s) => s.employeeId === emp.employeeId && s.period === period);
        const result = computeFromStoredScores(deptKpis, empScores);
        return { emp, result };
      });
  }, [data, period, staffFilter]);

  const deptAvgs = useMemo(() => DEPTS.map((dept) => {
    const deptResults = employeeResults.filter((r) => r.emp.departmentId === dept.id);
    const scores = deptResults.map((r) => r.result.finalScore).filter((s) => s > 0);
    return {
      dept: isAr ? dept.nameAr : dept.name,
      avg: scores.length > 0 ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10 : 0,
    };
  }), [employeeResults, isAr]);

  const gradeDist = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const { result } of employeeResults) {
      counts[result.grade] = (counts[result.grade] ?? 0) + 1;
    }
    return Object.entries(counts).map(([grade, count]) => ({
      name: isAr ? translateGrade(grade as Grade) : grade,
      value: count,
      fill: gradeColor(grade),
    }));
  }, [employeeResults, isAr]);

  const coachingCount = employeeResults.filter((r) => r.result.isCoaching).length;
  const avgKpi = useMemo(() => {
    const scores = employeeResults.map((r) => r.result.finalScore).filter((s) => s > 0);
    return scores.length > 0 ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10 : 0;
  }, [employeeResults]);

  const exitReasons = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const ex of data.exitRecords) {
      counts[ex.terminationReason] = (counts[ex.terminationReason] ?? 0) + 1;
    }
    return Object.entries(counts).map(([reason, count]) => ({ reason, count }));
  }, [data.exitRecords]);

  const trainingByDept = useMemo(() => DEPTS.map((dept) => {
    const deptEmps = data.employees.filter((e) => e.departmentId === dept.id && e.employmentStatus === "Active");
    const snaps = data.workforceSnapshots.filter(
      (s) => s.period === period && deptEmps.some((e) => e.employeeId === s.employeeId)
    );
    const avg = snaps.length > 0
      ? Math.round(snaps.reduce((a, b) => a + b.trainingHoursYtd, 0) / snaps.length) : 0;
    return { dept: isAr ? dept.nameAr : dept.name, avg };
  }), [data, period, isAr]);

  const filteredSorted = useMemo(() => {
    const q = tableSearch.toLowerCase();
    const rows = employeeResults.filter(({ emp }) =>
      emp.displayName.toLowerCase().includes(q) ||
      emp.fullNameAr?.includes(q) ||
      emp.employeeId.toLowerCase().includes(q)
    );
    return [...rows].sort((a, b) => {
      if (sortBy === "score") return b.result.finalScore - a.result.finalScore;
      if (sortBy === "dept") return a.emp.departmentId.localeCompare(b.emp.departmentId);
      return (isAr ? a.emp.displayNameAr : a.emp.displayName)
        .localeCompare(isAr ? b.emp.displayNameAr : b.emp.displayName);
    });
  }, [employeeResults, tableSearch, sortBy, isAr]);

  const kpiTrend = useMemo(() => PERIODS.map((p) => {
    const snaps = data.workforceSnapshots.filter(
      (s) => s.period === p && data.employees.find((e) => e.employeeId === s.employeeId)?.employmentStatus === "Active"
    );
    const scores = snaps.map((s) => s.performanceRating).filter((v): v is number => v != null);
    return {
      period: PERIOD_LABELS[p] ?? p,
      avg: scores.length > 0 ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10 : 0,
    };
  }), [data]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3 items-center">
        <select value={period} onChange={(e) => setPeriod(e.target.value)} className="ctrl">
          {PERIODS.map((p) => <option key={p} value={p}>{PERIOD_LABELS[p]}</option>)}
        </select>
        <select value={staffFilter} onChange={(e) => setStaffFilter(e.target.value as StaffFilter)} className="ctrl">
          <option value="all">{t.allStaff}</option>
          <option value="direct">{t.directStaff}</option>
          <option value="casual">{t.casualStaff}</option>
        </select>
        {staffFilter === "casual" && (
          <span className="text-xs px-2 py-1 rounded-full" style={{ background: "var(--gold-bg)", color: "var(--gold)" }}>
            {t.casualNote}
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={isAr ? "إجمالي الموظفين" : "Total Active"} value={employeeResults.length} />
        <StatCard label={t.avgPerformance} value={avgKpi} accent="var(--gold)" />
        <StatCard label={t.coachingLoad} value={coachingCount}
          sub={`${Math.round((coachingCount / Math.max(1, employeeResults.length)) * 100)}% ${isAr ? "يحتاجون تدريباً" : "need coaching"}`}
          accent="#F97316" />
        <StatCard label={isAr ? "إجمالي المغادرة" : "Total Exits"} value={data.exitRecords.length}
          sub={isAr ? "في جميع الفترات" : "across all periods"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartFrame title={t.avgKpiByDept} className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={deptAvgs} margin={{ left: -10 }}>
              <XAxis dataKey="dept" tick={{ fill: "var(--text-muted)", fontSize: 12 }} />
              <YAxis domain={[0, 100]} tick={{ fill: "var(--text-muted)", fontSize: 11 }} />
              <Tooltip contentStyle={TT_STYLE} />
              <Bar dataKey="avg" fill={tokens.gold} radius={[4, 4, 0, 0]} name={isAr ? "متوسط المؤشر" : "Avg KPI"} />
            </BarChart>
          </ResponsiveContainer>
        </ChartFrame>

        <ChartFrame title={t.gradeDistribution}>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={gradeDist} cx="50%" cy="45%" innerRadius={50} outerRadius={80} dataKey="value">
                {gradeDist.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Pie>
              <Tooltip contentStyle={TT_STYLE} />
              <Legend wrapperStyle={{ fontSize: 10, color: "var(--text-muted)" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartFrame>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartFrame title={t.kpiTrend} className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={kpiTrend} margin={{ left: -10 }}>
              <XAxis dataKey="period" tick={{ fill: "var(--text-muted)", fontSize: 11 }} />
              <YAxis domain={[60, 100]} tick={{ fill: "var(--text-muted)", fontSize: 11 }} />
              <Tooltip contentStyle={TT_STYLE} />
              <Line type="monotone" dataKey="avg" stroke={tokens.gold} strokeWidth={2} dot={{ fill: tokens.gold, r: 4 }} name={t.avgPerformance} />
            </LineChart>
          </ResponsiveContainer>
        </ChartFrame>

        <ChartFrame title={t.turnover}>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={exitReasons} layout="vertical" margin={{ left: 20 }}>
              <XAxis type="number" tick={{ fill: "var(--text-muted)", fontSize: 11 }} />
              <YAxis type="category" dataKey="reason" tick={{ fill: "var(--text-muted)", fontSize: 10 }} width={90} />
              <Tooltip contentStyle={TT_STYLE} />
              <Bar dataKey="count" fill={tokens.poor} radius={[0, 4, 4, 0]} name={isAr ? "العدد" : "Count"} />
            </BarChart>
          </ResponsiveContainer>
        </ChartFrame>
      </div>

      <ChartFrame title={t.trainingCompletion}>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={trainingByDept} margin={{ left: -10 }}>
            <XAxis dataKey="dept" tick={{ fill: "var(--text-muted)", fontSize: 12 }} />
            <YAxis tick={{ fill: "var(--text-muted)", fontSize: 11 }} />
            <Tooltip contentStyle={TT_STYLE} />
            <Bar dataKey="avg" fill={tokens.blue} radius={[4, 4, 0, 0]} name={isAr ? "متوسط الساعات" : "Avg Hrs"} />
          </BarChart>
        </ResponsiveContainer>
      </ChartFrame>

      {/* Vendor breakdown — shown when viewing all or casual */}
      {staffFilter !== "direct" && data.vendors?.length > 0 && (
        <ChartFrame title={t.vendorBreakdown}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs uppercase" style={{ color: "var(--text-muted)" }}>
                  <th className="text-start py-2 px-2">{t.vendor}</th>
                  <th className="text-start py-2 px-2">{isAr ? "الموظفون النشطون" : "Active Staff"}</th>
                  <th className="text-start py-2 px-2">{t.avgPerformance}</th>
                  <th className="text-start py-2 px-2">{t.department}</th>
                </tr>
              </thead>
              <tbody>
                {data.vendors.map((vendor) => {
                  const vendorEmps = data.employees.filter(
                    (e) => e.vendorId === vendor.id && e.employmentStatus === "Active"
                  );
                  const vendorResults = employeeResults.filter((r) => r.emp.vendorId === vendor.id);
                  const scores = vendorResults.map((r) => r.result.finalScore).filter((s) => s > 0);
                  const avg = scores.length > 0
                    ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10
                    : null;
                  const depts = [...new Set(vendorEmps.map((e) => e.departmentId))];
                  return (
                    <tr key={vendor.id} className="border-t" style={{ borderColor: "var(--border)" }}>
                      <td className="py-2 px-2 font-medium" style={{ color: "var(--text)" }}>
                        {isAr ? vendor.nameAr : vendor.name}
                      </td>
                      <td className="py-2 px-2" style={{ color: "var(--text-muted)" }}>{vendorEmps.length}</td>
                      <td className="py-2 px-2 font-bold" style={{ color: "var(--gold)" }}>
                        {avg ?? "—"}
                      </td>
                      <td className="py-2 px-2 text-xs" style={{ color: "var(--text-muted)" }}>
                        {depts.map((id) => DEPTS.find((d) => d.id === id)).map((d) => isAr ? d?.nameAr : d?.name).join(", ")}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </ChartFrame>
      )}

      <ChartFrame title={t.coachingQueue}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase" style={{ color: "var(--text-muted)" }}>
                <th className="text-start py-2 px-2">{t.name}</th>
                <th className="text-start py-2 px-2">{t.department}</th>
                <th className="text-start py-2 px-2">{t.finalKpi}</th>
                <th className="text-start py-2 px-2">{t.grade}</th>
                <th className="text-start py-2 px-2">{t.vendor}</th>
              </tr>
            </thead>
            <tbody>
              {employeeResults
                .filter((r) => r.result.isCoaching)
                .sort((a, b) => a.result.finalScore - b.result.finalScore)
                .map(({ emp, result }) => {
                  const deptName = DEPTS.find((d) => d.id === emp.departmentId);
                  const vendor = emp.vendorId ? data.vendors?.find((v) => v.id === emp.vendorId) : null;
                  return (
                    <tr key={emp.employeeId}
                      className="border-t"
                      style={{ borderColor: "var(--border)" }}
                    >
                      <td className="py-2 px-2 font-medium">
                        <button
                          onClick={() => setSelectedEmpId(emp.employeeId)}
                          className="hover:underline text-start"
                          style={{ color: "var(--gold)" }}
                        >
                          {isAr ? emp.displayNameAr : emp.displayName}
                        </button>
                        {emp.staffType === "casual" && (
                          <span className="ml-2 text-xs px-1.5 py-0.5 rounded" style={{ background: "rgba(37,99,235,0.12)", color: "var(--c-blue)" }}>
                            {isAr ? "شركة" : "Casual"}
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-2" style={{ color: "var(--text-muted)" }}>
                        {isAr ? deptName?.nameAr : deptName?.name}
                      </td>
                      <td className="py-2 px-2 font-bold" style={{ color: gradeColor(result.grade) }}>
                        {result.finalScore}
                      </td>
                      <td className="py-2 px-2">
                        <GradeBadge grade={result.grade} size="sm" />
                      </td>
                      <td className="py-2 px-2 text-xs" style={{ color: "var(--text-muted)" }}>
                        {vendor ? (isAr ? vendor.nameAr : vendor.name) : "—"}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
        <SyntheticDisclaimer />
      </ChartFrame>

      {/* Full employee performance table */}
      <ChartFrame title={isAr ? "جدول الموظفين الكامل" : "Full Employee Table"}>
        <div className="flex flex-wrap gap-2 mb-3">
          <input
            value={tableSearch}
            onChange={(e) => setTableSearch(e.target.value)}
            placeholder={t.search}
            className="ctrl flex-1 min-w-40"
          />
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value as typeof sortBy)} className="ctrl">
            <option value="score">{isAr ? "ترتيب: النتيجة" : "Sort: Score"}</option>
            <option value="name">{isAr ? "ترتيب: الاسم" : "Sort: Name"}</option>
            <option value="dept">{isAr ? "ترتيب: القسم" : "Sort: Dept"}</option>
          </select>
          <span className="text-xs self-center" style={{ color: "var(--text-muted)" }}>
            {filteredSorted.length} {isAr ? "موظف" : "employees"}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{ minWidth: 640 }}>
            <thead>
              <tr className="text-xs uppercase" style={{ color: "var(--text-muted)" }}>
                <th className="text-start py-2 px-2">#</th>
                <th className="text-start py-2 px-2">{t.name}</th>
                <th className="text-start py-2 px-2">{t.department}</th>
                <th className="text-start py-2 px-2">{t.staffType}</th>
                <th className="text-start py-2 px-2">{t.finalKpi}</th>
                <th className="text-start py-2 px-2">{t.grade}</th>
                <th className="text-start py-2 px-2 hidden md:table-cell">{t.avgTraining}</th>
                <th className="text-start py-2 px-2 hidden lg:table-cell">{t.nationality}</th>
                <th className="text-start py-2 px-2 hidden lg:table-cell">{t.gender}</th>
              </tr>
            </thead>
            <tbody>
              {filteredSorted.map(({ emp, result }, i) => {
                const deptName = DEPTS.find((d) => d.id === emp.departmentId);
                const snap = data.workforceSnapshots.find(
                  (s) => s.employeeId === emp.employeeId && s.period === period
                );
                return (
                  <tr key={emp.employeeId}
                    className="border-t"
                    style={{
                      borderColor: "var(--border)",
                      backgroundColor: result.isCoaching ? "rgba(249,115,22,0.04)" : undefined,
                    }}
                  >
                    <td className="py-2 px-2 text-xs" style={{ color: "var(--text-muted)" }}>{i + 1}</td>
                    <td className="py-2 px-2">
                      <button
                        onClick={() => setSelectedEmpId(emp.employeeId)}
                        className="font-medium hover:underline text-start"
                        style={{ color: "var(--gold)" }}
                      >
                        {isAr ? emp.displayNameAr : emp.displayName}
                      </button>
                      {emp.staffType === "casual" && (
                        <span className="ml-2 text-xs px-1.5 py-0.5 rounded" style={{ background: "rgba(37,99,235,0.12)", color: "var(--c-blue)" }}>
                          {isAr ? "شركة" : "Casual"}
                        </span>
                      )}
                      {result.isCoaching && <span className="ml-1 text-xs" style={{ color: "#F97316" }}>⚠</span>}
                    </td>
                    <td className="py-2 px-2 text-xs" style={{ color: "var(--text-muted)" }}>
                      {isAr ? deptName?.nameAr : deptName?.name}
                    </td>
                    <td className="py-2 px-2 text-xs" style={{ color: emp.staffType === "casual" ? "var(--c-blue)" : "var(--text-muted)" }}>
                      {emp.staffType === "casual" ? (isAr ? "شركة" : "Casual") : (isAr ? "مباشر" : "Direct")}
                    </td>
                    <td className="py-2 px-2 font-bold" style={{ color: gradeColor(result.grade) }}>
                      {result.finalScore > 0 ? result.finalScore : "—"}
                    </td>
                    <td className="py-2 px-2">
                      {result.finalScore > 0 ? <GradeBadge grade={result.grade} size="sm" /> : <span style={{ color: "var(--text-faint)" }}>—</span>}
                    </td>
                    <td className="py-2 px-2 hidden md:table-cell text-xs" style={{ color: snap && snap.trainingHoursYtd < COACHING_THRESHOLD ? "#F97316" : "var(--text-muted)" }}>
                      {snap ? `${snap.trainingHoursYtd}h` : "—"}
                    </td>
                    <td className="py-2 px-2 hidden lg:table-cell text-xs" style={{ color: "var(--text-muted)" }}>
                      {isAr ? (emp.nationality === "Saudi" ? "سعودي" : "غير سعودي") : emp.nationality}
                    </td>
                    <td className="py-2 px-2 hidden lg:table-cell text-xs" style={{ color: "var(--text-muted)" }}>
                      {isAr ? (emp.gender === "M" ? "ذكر" : "أنثى") : (emp.gender === "M" ? "M" : "F")}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </ChartFrame>

      {selectedEmpId && (
        <EmployeeProfileModal
          employeeId={selectedEmpId}
          data={data}
          onClose={() => setSelectedEmpId(null)}
        />
      )}
    </div>
  );
}

function translateGrade(grade: Grade): string {
  const map: Record<Grade, string> = {
    Exceptional: "متميز", Excellent: "ممتاز", Good: "جيد",
    Fair: "مقبول", "Needs Improvement": "يحتاج تطوير",
  };
  return map[grade] ?? grade;
}
